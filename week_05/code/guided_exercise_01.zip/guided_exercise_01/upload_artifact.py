"""
Creator: Ivanovitch Silva
Date: 19 Nov. 2021
Guided Exercise 01
Versioning Data and Artifacts with Argparse & Weights and Biases
Upload an artifact to Weights and Biases.
"""
import argparse
import logging
import pathlib
import wandb


# configure logging
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(message)s",
                    datefmt='%d-%m-%Y %H:%M:%S')

# reference for a logging obj
logger = logging.getLogger()


def process_args(args):
    """
    Using args, and upload an artifact
    to weights & biases
    Param
        args - command line arguments
    """

    logger.info("Creating run exercise_1")
    run = wandb.init(project="guided_exercise_1",
                     job_type="upload_file")

    logger.info("Creating artifact")
    artifact = wandb.Artifact(name=args.artifact_name,
                              type=args.artifact_type,
                              description=args.artifact_description
                              )
    artifact.add_file(args.input_file)

    logger.info("Logging artifact")
    run.log_artifact(artifact)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="Upload an artifact to W&B", fromfile_prefix_chars="@"
    )

    # add the argument input_file
    parser.add_argument(
        "--input_file",
        type=pathlib.Path,
        help="Path to the input file",
        required=True)

    # add the argument artifact_name
    parser.add_argument(
        "--artifact_name",
        type=str,
        help="Name for the artifact",
        required=True)

    # add the argument artifact_type
    parser.add_argument(
        "--artifact_type",
        type=str,
        help="Type for the artifact",
        required=True)

    # add the argument artifact_description
    parser.add_argument(
        "--artifact_description",
        type=str,
        help="Description for the artifact",
        required=True
    )

    # get arguments
    ARGS = parser.parse_args()

    # call the call`s handle
    process_args(ARGS)

# Command Line to run this script
# python upload_artifact.py --input_file zen.txt \
#               --artifact_name zen_of_python \
#               --artifact_type text_file \
#               --artifact_description "20 aphorisms about writing good python code"
