"""
Creator: Ivanovitch Silva
Date: 19 Nov. 2021
Guided Exercise 01
Versioning Data and Artifacts with Argparse & Weights and Biases
Use an artifact donwloaded from Weights and Biases.
"""
import argparse
import logging
import wandb


# configure logging
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(message)s",
                    datefmt='%d-%m-%Y %H:%M:%S')

# reference for a logging obj
logger = logging.getLogger()


def process_args(args):
    """
    Using args, get the artifact_name
    and download artifact from weights & biases
    Param
        args - command line arguments
    """

    logger.info("Creating run in project exercise_1")
    run = wandb.init(project="guided_exercise_1",
                     job_type="use_file")

    logger.info("Getting artifact")
    artifact = run.use_artifact(args.artifact_name)

    logger.info("Artifact content:")
    filepath = artifact.file()

    with open(filepath, "r") as file:
        content = file.read()

    print(content)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="Use an artifact from W&B", fromfile_prefix_chars="@"
    )

    # add the argument artifact_name
    parser.add_argument(
        "--artifact_name",
        type=str,
        help="Name and version of W&B artifact",
        required=True
    )

    # get arguments
    ARGS = parser.parse_args()

    # call the call`s handle
    process_args(ARGS)
    
# how to run this script
# python use_artifact.py --artifact_name guided_exercise_1/zen_of_python:v1

